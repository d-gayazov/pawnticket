-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 30 2022 г., 15:11
-- Версия сервера: 8.0.29
-- Версия PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `pawnticket`
--

-- --------------------------------------------------------

--
-- Структура таблицы `deposit`
--

CREATE TABLE `deposit` (
  `id` int NOT NULL,
  `client_fio` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `client_phone` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `deposit_title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `loan_amount` double DEFAULT NULL,
  `pawn_condition` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `period_days` int DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `valuation` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `deposit`
--

INSERT INTO `deposit` (`id`, `client_fio`, `client_phone`, `date`, `deposit_title`, `loan_amount`, `pawn_condition`, `period_days`, `total_amount`, `valuation`) VALUES
(1, 'Иванов Иван Иванович', '89171234567', '2022-08-30 15:07:38.690000', 'Цепочка золотая, 585пр, 3гр.', 4000, 'Царапины, помято 3 звена', 14, 4280, 5000),
(2, 'Петров Петр Петрович', '89671234567', '2022-08-30 15:07:57.256000', 'Смартфон IPhone 12, Белого цвета,1 шт.IMEI 111111111111111', 45000, 'Скол в верхнем правом углу', 18, 49050, 50000),
(3, 'Сидоров Иван Петрович', '89281234567', '2022-08-30 15:08:22.794000', 'Ноутбук SamsungEX837, сер.номер 03354935568234', 25000, 'Потертости, отсутствует клавиша Enter', 25, 28125, 20000);

-- --------------------------------------------------------

--
-- Структура таблицы `hibernate_sequence`
--

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `hibernate_sequence`
--

INSERT INTO `hibernate_sequence` (`next_val`) VALUES
(4);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
